package se2aa4;
/**
 * This enum is used to identify panels
 * of the menu to be displayed.
 */
public enum BoardPanels {
	EMPTY,START,EDIT,PLAY,TO_MAIN_MENU;
}
